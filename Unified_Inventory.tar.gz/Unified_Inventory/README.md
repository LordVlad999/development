Unified inventory
=================

Unified Inventory replaces the default survival and creative inventory.
It adds a nicer interface and a number of features, such as a crafting guide.

License
=======

Copyright (C) 2012-2014 Maciej Kasatkin (RealBadAngel)

Unified inventory code is licensed under the GNU LGPLv2+.

Licenses for textures:

VanessaE: (WTFPL)
  * `ui_group.png`

RealBadAngel: (WTFPL)
  * Everything else.

Tango Project: (WTFPL)
  * `ui_reset_icon.png`
