--ESCRIBIENDO POSICIONES. CADA LOCAL VARIABLE (SPAWN, ETC) SON LUGARES
--lg ES LA LISTA DE TODOS LOS LUGARES
local spawn = { x = 0, y = 30, z = 0 }
local casa

minetest.register_on_chat_message(function(name, message)
if message == "lp" then
minetest.chat_send_player(name, "Lista de posiciones:*spawn*casa")
end
end)

minetest.register_on_chat_message(function(name, message)
if message == "spawn" then
position = minetest.get_player_by_name(name)
position:setpos(spawn)
--minetest.sound_play("teleport", {
--	max_hear_distance = 50,
--})
minetest.chat_send_player(name, "Moviendo al Spawn....")
end
end)

--EL ESQUEMA PARA TELETRANSPORTARSE, PERO PRIMERO DEBE HABER UNA VARIABLE -LOCAL- AL PRINCIPIO
--minetest.register_on_chat_message(function(name, message)
--	if message == "lg" then
--		position = minetest.get_player_by_name(name)
--		position:setpos(spawn)
--		minetest.chat_send_player(name, "Moviendo al spawn....")
--	end
--end)

minetest.register_chatcommand("who", {
    params = "",
    description = "List all connected players.",
    func = function(name)
        connected_players_string = 'Conectados: '
 
        for _,player in ipairs(minetest.get_connected_players()) do
            connected_players_string  =  connected_players_string .. 
                                         player:get_player_name() .. 
                                         ' '
        end
 
        minetest.chat_send_player(name, connected_players_string)
 
        return true
    end
})

