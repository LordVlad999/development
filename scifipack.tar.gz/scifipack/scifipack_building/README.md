#Scifipack Building
A Minetest mod made by foot\_on\_teh\_hill

##About:
This Minetest mod adds science fiction inspired building blocks.

##Nodes included:
- scifipack\_building:hexfloor
- scifipack\_building:steelpanel1
- scifipack\_building:frostyglowglass

##Dependencies:
This mod depends on the default and dye mods. There is an optional dependency on moreblocks to enable the use of microblocks for some nodes.

##License:
Source code: WTFPL Version 2
Textures: CC BY-SA 3.0

##Thanks:
Thanks to rubenwardy for the Minetest Modding Book, which has helped me
greatly in developing this mod, and to all Minetest developers.

