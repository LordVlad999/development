#Cavetools mod for Minetest
Made by foot_on_teh_hill

##About:
This is a Minetest mod which adds some tools which makes it easier to move
around or manipulate the world. At the moment the mod contains a rope for
climbing or descending, and drills that drill 1x1 holes of varying depths.

Contains:

- cavetools:rope
- cavetools:minidrill
- cavetools:drill
- cavetools:deepdrill

##Dependencies:
This mod depends on the farming mod. There is an optional dependency on the
moreores mod for the deep drill crafting recipe.

##License:
Source code: WTFPL Version 2
Textures: CC BY-SA 3.0

##Thanks:
Thanks to rubenwardy for the Minetest Modding Book, which has helped me
greatly in developing this mod, and to all Minetest developers.

Thanks to Gabo, Amaz, fishyWET and nanepiwo for feedback on the function
of the tools.


