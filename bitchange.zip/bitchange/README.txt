Bitchange
=========

This mod adds the currency "MineCoin" to your Minetest world.
To change a setting, edit the file 'bitchange_config.txt' in your world directory.
Copy and paste 'config.default.txt' if the file does not exist yet.

License:	WTFPL (for code and textures)
Adds privilege:	bitchange

Dependencies:
	default
	moreores		(optional)
	technic_worldgen	(optional)
	quartz			(optional)
	pipeworks		(optional)
	money			(optional)
	money2			(optional)
	currency		(optional)

Forum link: https://forum.minetest.net/viewtopic.php?id=7821

Requires Minetest 0.4.14 (stable) or newer.
