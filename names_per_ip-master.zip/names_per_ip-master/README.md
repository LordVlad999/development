names_per_ip
============

A mod for Minetest to stop annoyed kids

It will limit the accounts to 2 (+3 if the player is whitelisted) per IP and delete IP history.

Initial mod creator: Krock

License: WTFPL

Depends: nothing

Chat commands
-------------

```
/ipnames
	whois <name>	-> Gets all accounts of <name>
	list		-> Lists all exceptions/whitelist entries (players which can have "unlimited" accounts)
	ignore <name>	-> Adds an exception/whitelist entry for <name>
	unignore <name>	-> Removes an exception/whitelist entry for <name>
```
