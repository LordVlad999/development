dofile(minetest.get_modpath("my_default_doors").."/locked.lua")
--dofile(minetest.get_modpath("my_default_doors").."/unlocked.lua")


