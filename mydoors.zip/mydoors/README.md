# mydoors
Mydoors is a modpack with many door styles.

This is a modpack that adds over 50 doors to minetest. It is set up as a mod pack so you  can choose the style of doors you want without adding them all.
It has everything from old fashion doors to futuristic sliding doors.

Forum - https://forum.minetest.net/viewtopic.php?f=11&t=10626

Licence - DWYWPL
