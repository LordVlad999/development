LIGHTSPLUS
==========

Lights+ mod for Minetest.

This mod adds a collection of white and gold lights that are activated/deactivated by punching them.
White light texture by VanessaE, gold light texture by paramat, original code for flat lights by LionsDen. 
