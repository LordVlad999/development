--Fireworks V3.0 by: crazyginger72
--License code and textures WTFPL 
--original mod by: InfinityProject, Mauvebic, Cornernote, and Neuromancer

--REWRITE BY: crayzginger72 (2014)

