-- Aliases for compatibility with 0gb.us's chests_0gb_us mod.
minetest.register_alias("chests_0gb_us:cobble", "more_chests:cobble")
minetest.register_alias("chests_0gb_us:wifi", "more_chests:wifi")
minetest.register_alias("chests_0gb_us:shared", "more_chests:shared")
minetest.register_alias("chests_0gb_us:secret", "more_chests:secret")
minetest.register_alias("chests_0gb_us:dropbox", "more_chests:dropbox")
