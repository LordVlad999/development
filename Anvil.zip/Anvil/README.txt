Anvil mod by Sokomine, originally a part of the Cottages mod but extracted to stand alone.

This anvil (and its associated hammer) allows a player to repair worn tools. Place the worn tool in the anvil's inventory and strike it with the hammer to improve its condition.