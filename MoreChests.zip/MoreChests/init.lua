dofile(minetest.get_modpath("more_chests").."/cobble.lua")
dofile(minetest.get_modpath("more_chests").."/dropbox.lua")
dofile(minetest.get_modpath("more_chests").."/secret.lua")
dofile(minetest.get_modpath("more_chests").."/shared.lua")
dofile(minetest.get_modpath("more_chests").."/wifi.lua")
dofile(minetest.get_modpath("more_chests").."/aliases.lua")

