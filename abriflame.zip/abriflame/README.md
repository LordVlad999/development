abriflame
=========

Coloured flames Minetest mod by Shara RedCat which adds:

1. Ten decorative, non-destructive fire types.
2. A fire starter tool to create them.

Note: This mod depends on [abriglass](https://github.com/Ezhh/abriglass) and will not work without it.


Crafting
---------

To create coloured flames, first craft a fire starter tool using a steel ingot and a mese crystal fragment.

Place a node of coloured glass (non-patterned) from the abriglass mod.

While holding the tool, left click the glass node. Coloured flame will appear above the glass. 

You can remove and replace the glass node with something else, and the flame will remain.


Licenses and Attribution 
-----------------------

Please see license.txt for details.