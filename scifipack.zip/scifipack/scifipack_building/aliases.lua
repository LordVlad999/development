minetest.register_alias("scifipack:hexfloor", "scifipack_building:hexfloor")
