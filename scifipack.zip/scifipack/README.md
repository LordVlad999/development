#Science Fiction mod package
A Minetest mod package made by foot\_on\_teh\_hill with contributors.

##Contributions by:
Amaz

##Mods included:
- Scifipack Building (scifipack\_building)
- Scifipack Neon Lights (scifipack\_neon)
- Scifipack Panels (scifipack\_panels)

See the README file for the individual mods to get more info about them.

##License:
Source code: WTFPL Version 2
Textures: CC BY-SA 3.0

##Thanks:
Thanks to rubenwardy for the Minetest Modding Book, which has helped me
greatly in developing this mod, and to all Minetest developers.

