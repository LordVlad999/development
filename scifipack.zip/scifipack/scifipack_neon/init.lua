scifipack_neon = {}

dofile(minetest.get_modpath("scifipack_neon").."/lights.lua")
dofile(minetest.get_modpath("scifipack_neon").."/aliases.lua")

