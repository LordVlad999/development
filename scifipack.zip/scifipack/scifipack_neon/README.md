#Scifipack Neon Lights
A Minetest mod made by foot\_on\_teh\_hill with contributors.

##About:
This Minetest mod adds neon-styled lights in a variety of colors.

##Contributions by:
Amaz

##Nodes included:
- scifipack\_neon:linelight[color]
- scifipack\_neon:cornerlight[color]
- scifipack\_neon:stairlight[color]

[color] is one of the following:
red, yellow, orange, blue, green, magenta, violet

##Dependencies:
This mod depends on the default and dye mods.

##License:
Source code: WTFPL Version 2
Textures: CC BY-SA 3.0

##Thanks:
Thanks to rubenwardy for the Minetest Modding Book, which has helped me
greatly in developing this mod, and to all Minetest developers.

