#Scifipack Panels
A Minetest mod made by foot\_on\_teh\_hill

##About:
This Minetest mod adds a selection of panels with a science fiction inspired look which can be used for building.

A panel factory is required to produce the panels. The panel factory takes panels or steel ingots as input and produces panels as output. The panel factory can only be used by the owner.

##Dependencies:
This mod depends on the default mod. 

##License:
Source code: WTFPL Version 2
Textures: CC BY-SA 3.0

##Thanks:
Thanks to rubenwardy for the Minetest Modding Book, which has helped me
greatly in developing this mod, and to all Minetest developers.

