scifipack_panels = {}

dofile(minetest.get_modpath("scifipack_panels") .. "/nodes.lua")
dofile(minetest.get_modpath("scifipack_panels") .. "/panel_factory.lua")
dofile(minetest.get_modpath("scifipack_panels") .. "/crafting.lua")
