minetest.register_craft({
	output = "scifipack_panels:factory",
	recipe = {
		{"",					"default:obsidian_shard",	""},
		{"default:steel_ingot",	"default:mese_crystal",		"default:steel_ingot"},
		{"default:steel_ingot",	"",							"default:steel_ingot"}
	}
})

