###Flyingcarpets: a mod for Minetest
Flying carpets is a mod that allows players to make a flying carpet, and fly with it!

####What this mod does:
This mod provides carpets that you can fly on, with the code based on the [Helicopter mod.](https://forum.minetest.net/viewtopic.php?id=6183)

####Configeration:
This mod can be configured through the config.lua file. Each option has a description of what it controls above it. I recommend checking through the file before you use the mod, just to check everything is okay for use with your game/server.

####Dependencies:
This mod only depends on default, as it uses a function from there.

####Todo:
- Add more verity of carpets?

####Licenses:
Images and models are licensed under the WFTPL.
Code is under the LGPL v2.1, as I think this is what the Helicopters mod is licensed under... Please correct me if I am wrong!
