##Flight: A modpack for Minetest
###Intro:
This modpack is currently made made up of three mods: wings, jetpack and flyingcarpet!
Two of these mods have a dependency on [Wuzzy's playereffects mod](https://forum.minetest.net/viewtopic.php?f=11&t=9689)
All of the mods can be configured extensively through the config.lua file found in each mod.

Look at the readme's of the mods for more info.
