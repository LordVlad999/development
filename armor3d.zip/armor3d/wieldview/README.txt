[mod] visible wielded items [wieldview]
=======================================

depends: default, 3d_armor

Makes hand wielded items visible to other players.

default settings: [minetest.conf]

# Set number of seconds between visible wielded item updates.
wieldview_update_time = 2

# Show nodes as tiles, disabled by default
wieldview_node_tiles = false

