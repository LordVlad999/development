#Streets mod 2.0
_Released on 21st of February 2017_

_Streets 2.0 is **not** fully backwards-compatible to streets 1.x!_

##Contributors

* webdesigner97
* cheapie
* Thomas-S
* HybridDog (for `streets_matrix_screen` submod)

##Recommended Mods
* [ltc4000e](https://github.com/cheapie/ltc4000e) by cheapie
* [arrowboards](https://github.com/cheapie/arrowboards) by cheapie

##License
If not mentioned otherwise:

###Code
MIT License

###Media
CC-BY-SA 3.0

### License File
See the file `LICENSE` for more details.
