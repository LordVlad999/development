Rainbow Ore
===========

This mod features a new ore called "Rainbow Ore" (as if you guessed it :D) wich is pretty rare but also pretty powerful.

License
=======

Copyright (C) 2015 Robin Kuhn (KingSmarty)

Rainbow Ore code is licensed under the GNU LGPLv2.1.

Textures are licensed under the same license as minetest_game.

Crafting:
=========

Smelt "Rainbow Ore Block" --> "Rainbow Ingots"

Tools are crafted as always but with "Rainbow Ingots" as material instead.

Armor is crafted like Armor but with "Rainbow Ingots" as material instead.

Shield are crafted like a shield but with "Rainbow Ingots" as material instead.

You can craft Nyancat_rainbow blocks like any other "solid" blocks but with "Rainbow Ingots" as material instead.