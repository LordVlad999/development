Technic
=======

Credits for contributing to the project (in alphabetical order):
  * kpoppel
  * Nekogloop
  * Nore/Ekdohibs
  * ShadowNinja
  * VanessaE
  * And many others...

FAQ
---

1. My technic circuit doesn't work.  No power is distrubuted.
  * A: Make sure you have a switching station connected.

License
-------

Unless otherwise stated, all components of this modpack are licensed under the 
LGPL, V2 or later.  See also the individual mod folders for their
secondary/alternate licenses, if any.
